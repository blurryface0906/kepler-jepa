"""Task 2 sequence encoders and horizon-conditioned JEPA research baselines.

All constructors default to float32. For numerical spectral experiments pass
``dtype=torch.float64`` at construction: weights are then sampled and initialized
in float64, rather than quantized in float32 before conversion. These are the
controlled 1D architectures specified by this project, not exact reproductions
of the papers' complete training pipelines.

Encoders consume (B, L, C); ``encode_sequence`` consumes (T, L, C), or optionally
(B, T, L, C), and preserves the leading dimensions. Rollouts consume (B, d) and
return (B, steps, d), excluding z0. They retain gradients, so callers conducting
evaluation should use ``eval()`` and ``torch.inference_mode()``.
"""

import copy
import math
from numbers import Integral, Real

import torch
from torch import nn

from .losses import ijepa_prediction_loss, opf_orthogonality_loss, sigreg_isotropic_loss


def _positive_int(value, name):
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 1:
        raise ValueError(f"{name} must be a positive integer")
    return int(value)


def _dtype(dtype):
    if dtype not in (torch.float32, torch.float64):
        raise ValueError("dtype must be torch.float32 or torch.float64")


def _weight(value, name):
    if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value) or value < 0:
        raise ValueError(f"{name} must be finite and nonnegative")
    return float(value)


def _orthogonal_init(module):
    if isinstance(module, nn.Linear):
        nn.init.orthogonal_(module.weight)
        if module.bias is not None:
            nn.init.constant_(module.bias, 1e-3)
    elif isinstance(module, nn.MultiheadAttention):
        # The fused Q/K/V projection is a parameter, not an nn.Linear child.
        if module.in_proj_weight is not None:
            nn.init.orthogonal_(module.in_proj_weight)
        if module.in_proj_bias is not None:
            nn.init.constant_(module.in_proj_bias, 1e-3)


def _sinusoidal(length, d, *, dtype, device):
    position = torch.arange(length, dtype=dtype, device=device).unsqueeze(1)
    inverse = torch.exp(torch.arange(0, d, 2, dtype=dtype, device=device)
                        * (-math.log(10000.0) / d))
    phase = position * inverse
    encoding = torch.zeros(length, d, dtype=dtype, device=device)
    encoding[:, 0::2] = phase.sin()
    encoding[:, 1::2] = phase[:, :d // 2].cos()
    return encoding


class SequenceEncoder(nn.Module):
    """Flattened linear/MLP encoder, or two-layer pre-norm transformer."""

    def __init__(self, L=16, C=4, d=64, arch_type="linear", *,
                 dtype=torch.float32, device=None):
        super().__init__()
        self.L, self.C, self.d = (_positive_int(value, name)
                                 for value, name in ((L, "L"), (C, "C"), (d, "d")))
        _dtype(dtype)
        if arch_type not in ("linear", "mlp", "transformer"):
            raise ValueError("arch_type must be 'linear', 'mlp', or 'transformer'")
        self.arch_type = arch_type
        factory = {"dtype": dtype, "device": device}
        if arch_type == "linear":
            self.network = nn.Linear(self.L * self.C, self.d, bias=True, **factory)
        elif arch_type == "mlp":
            self.network = nn.Sequential(
                nn.Linear(self.L * self.C, 128, **factory), nn.GELU(),
                nn.Linear(128, 128, **factory), nn.GELU(),
                nn.Linear(128, self.d, **factory),
            )
        else:
            if self.d % 4:
                raise ValueError("transformer latent dimension d must be divisible by 4")
            self.input_projection = nn.Linear(self.C, self.d, **factory)
            self.register_buffer("position_encoding", _sinusoidal(
                self.L, self.d, dtype=dtype, device=device))
            layer = nn.TransformerEncoderLayer(
                d_model=self.d, nhead=4, dim_feedforward=128,
                batch_first=True, norm_first=True, **factory)
            self.network = nn.TransformerEncoder(layer, num_layers=2,
                                                 enable_nested_tensor=False)
        # Applied after the transformer clones its layers, giving each its own
        # orthogonal draw instead of leaving identically initialized clones.
        self.apply(_orthogonal_init)

    def forward(self, x):
        if not isinstance(x, torch.Tensor) or x.ndim != 3 or x.shape[1:] != (self.L, self.C):
            raise ValueError(f"x must have shape (B, {self.L}, {self.C})")
        if self.arch_type == "transformer":
            tokens = self.input_projection(x) + self.position_encoding.unsqueeze(0)
            return self.network(tokens).mean(dim=1)
        return self.network(x.flatten(start_dim=1))


class HorizonPredictor(nn.Module):
    """Residual MLP ``z + MLP(z + embedding[k])`` for k in 1..H_max."""

    def __init__(self, d=64, H_max=64, *, dtype=torch.float32, device=None):
        super().__init__()
        self.d, self.H_max = _positive_int(d, "d"), _positive_int(H_max, "H_max")
        _dtype(dtype)
        factory = {"dtype": dtype, "device": device}
        self.pos_emb = nn.Parameter(torch.empty(self.H_max + 1, self.d, **factory))
        nn.init.normal_(self.pos_emb, std=0.02)
        self.mlp = nn.Sequential(nn.Linear(self.d, 128, **factory), nn.GELU(),
                                 nn.Linear(128, self.d, **factory))
        self.apply(_orthogonal_init)

    def forward(self, z_t, k=1):
        if not isinstance(z_t, torch.Tensor) or z_t.ndim != 2 or z_t.shape[1] != self.d:
            raise ValueError(f"z_t must have shape (B, {self.d})")
        if isinstance(k, bool):
            raise ValueError("k must be an integer or integer tensor")
        if isinstance(k, Integral):
            if not 1 <= k <= self.H_max:
                raise ValueError("k must lie in 1..H_max")
            embedding = self.pos_emb[int(k)]
        elif isinstance(k, torch.Tensor):
            if k.dtype not in (torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64):
                raise ValueError("k tensor must contain integer horizon indices")
            if k.ndim not in (0, 1) or (k.ndim == 1 and k.shape[0] != z_t.shape[0]):
                raise ValueError("k must be scalar or have shape (B,)")
            if torch.any((k < 1) | (k > self.H_max)):
                raise ValueError("all k values must lie in 1..H_max")
            embedding = self.pos_emb[k.to(device=self.pos_emb.device, dtype=torch.long)]
        else:
            raise ValueError("k must be an integer or integer tensor")
        return z_t + self.mlp(z_t + embedding)


class _WorldModel(nn.Module):
    """Common T1/T3/T4 evaluation API; no training or inference mode changes."""

    @property
    def encoder(self):
        """Alias for the context encoder without duplicate state-dict keys."""
        return self.context_encoder

    def forward(self, x_c, k=1):
        return self.predictor(self.context_encoder(x_c), k)

    def encode_sequence(self, traj_windows, batch_size=None):
        if not isinstance(traj_windows, torch.Tensor) or traj_windows.ndim not in (3, 4):
            raise ValueError("traj_windows must have shape (T,L,C) or (B,T,L,C)")
        encoder = self.context_encoder
        if traj_windows.shape[-2:] != (encoder.L, encoder.C):
            raise ValueError("window dimensions must match the context encoder")
        leading = traj_windows.shape[:-2]
        flattened = traj_windows.reshape(-1, encoder.L, encoder.C)
        if batch_size is None:
            encoded = encoder(flattened)
        else:
            batch_size = _positive_int(batch_size, "batch_size")
            if flattened.shape[0] == 0:
                encoded = flattened.new_empty((0, encoder.d))
            else:
                encoded = torch.cat([encoder(chunk) for chunk in flattened.split(batch_size)], dim=0)
        return encoded.reshape(*leading, encoder.d)

    def _rollout_steps(self, z0, steps, direct=False):
        if not isinstance(z0, torch.Tensor) or z0.ndim != 2 or z0.shape[1] != self.context_encoder.d:
            raise ValueError(f"z0 must have shape (B, {self.context_encoder.d})")
        if isinstance(steps, bool) or not isinstance(steps, Integral) or steps < 0:
            raise ValueError("steps must be a nonnegative integer")
        if direct and steps > self.predictor.H_max:
            raise ValueError("direct rollout exceeds H_max")
        return int(steps)

    def rollout_autoregressive(self, z0, steps):
        """T3: repeatedly apply horizon 1, preserving the computation graph."""
        steps = self._rollout_steps(z0, steps)
        state, outputs = z0, []
        for _ in range(steps):
            state = self.predictor(state, 1)
            outputs.append(state)
        return torch.stack(outputs, dim=1) if outputs else z0.new_empty((z0.shape[0], 0, z0.shape[1]))

    def rollout_direct(self, z0, steps):
        """T4: predict horizons 1..steps from the same initial state."""
        steps = self._rollout_steps(z0, steps, direct=True)
        outputs = [self.predictor(z0, k) for k in range(1, steps + 1)]
        return torch.stack(outputs, dim=1) if outputs else z0.new_empty((z0.shape[0], 0, z0.shape[1]))


class M0_RandomJEPA(_WorldModel):
    """Untrained frozen encoder/predictor, including the Exp1 transformer."""

    def __init__(self, L=16, C=4, d=64, H_max=64, arch_type="linear", *,
                 dtype=torch.float32, device=None):
        super().__init__()
        self.context_encoder = SequenceEncoder(L, C, d, arch_type, dtype=dtype, device=device)
        self.predictor = HorizonPredictor(d, H_max, dtype=dtype, device=device)
        self.requires_grad_(False)


class M1_IJEPA1D(_WorldModel):
    """Context/EMA-target pair with a shared horizon-conditioned predictor."""

    def __init__(self, L=16, C=4, d=64, H_max=64, arch_type="mlp", *,
                 dtype=torch.float32, device=None):
        super().__init__()
        self.context_encoder = SequenceEncoder(L, C, d, arch_type, dtype=dtype, device=device)
        self.target_encoder = copy.deepcopy(self.context_encoder).requires_grad_(False)
        self.target_encoder.eval()
        self.predictor = HorizonPredictor(d, H_max, dtype=dtype, device=device)

    def train(self, mode=True):
        super().train(mode)
        # Target features are deterministic even when the context has dropout.
        self.target_encoder.eval()
        return self

    @torch.no_grad()
    def update_target_ema(self, momentum=0.996):
        if (isinstance(momentum, bool) or not isinstance(momentum, Real)
                or not math.isfinite(momentum) or not 0 <= momentum <= 1):
            raise ValueError("momentum must be finite and lie in [0,1]")
        for target, context in zip(self.target_encoder.parameters(), self.context_encoder.parameters()):
            target.mul_(momentum).add_(context, alpha=1 - momentum)
        for target, context in zip(self.target_encoder.buffers(), self.context_encoder.buffers()):
            if target.is_floating_point():
                target.mul_(momentum).add_(context, alpha=1 - momentum)
            else:
                target.copy_(context)

    def compute_loss(self, z_pred, z_target, *, z_context=None):
        """Prediction-only objective; z_context is used by regularized subclasses."""
        return ijepa_prediction_loss(z_pred, z_target)

    def training_loss(self, x_c, x_target, k=1, **loss_kwargs):
        """Encode a batch of context/target windows and evaluate its objective."""
        z_context = self.context_encoder(x_c)
        z_pred = self.predictor(z_context, k)
        with torch.no_grad():
            z_target = self.target_encoder(x_target)
        return self.compute_loss(z_pred, z_target, z_context=z_context, **loss_kwargs)


class _FactorizedPredictor(nn.Module):
    def __init__(self, d, K, H_max, *, dtype, device):
        super().__init__()
        self.d, self.K, self.H_max = d, K, _positive_int(H_max, "H_max")
        self.predictors = nn.ModuleList([
            HorizonPredictor(d // K, H_max, dtype=dtype, device=device) for _ in range(K)
        ])

    def forward(self, z_t, k=1):
        if not isinstance(z_t, torch.Tensor) or z_t.ndim != 2 or z_t.shape[1] != self.d:
            raise ValueError(f"z_t must have shape (B, {self.d})")
        return torch.cat([predictor(factor, k) for predictor, factor in
                          zip(self.predictors, z_t.split(self.d // self.K, dim=-1))], dim=-1)


class M2_JEPA_OPF(M1_IJEPA1D):
    """Independent horizon predictors for equal contiguous latent factors."""

    def __init__(self, L=16, C=4, d=64, H_max=64, K=4, arch_type="mlp", *,
                 dtype=torch.float32, device=None):
        K = _positive_int(K, "K")
        d = _positive_int(d, "d")
        if d % K:
            raise ValueError("K must divide d")
        super().__init__(L, C, d, H_max, arch_type, dtype=dtype, device=device)
        self.K, self.d_f = K, d // K
        self.predictor = _FactorizedPredictor(d, K, H_max, dtype=dtype, device=device)

    @property
    def predictors(self):
        return self.predictor.predictors

    def get_active_factor(self, Z_seq):
        """Return the index with maximum trace of temporal sample covariance.

        Accept (T,d) or (B,T,d); for batched sequences average the per-sequence
        temporal variances, without mixing between-orbit offsets into variance.
        Ties select the first index, consistently with torch.argmax.
        """
        if (not isinstance(Z_seq, torch.Tensor) or not Z_seq.is_floating_point()
                or Z_seq.ndim not in (2, 3) or Z_seq.shape[-1] != self.context_encoder.d
                or Z_seq.shape[-2] < 2):
            raise ValueError("Z_seq must have shape (T>=2,d) or (B,T>=2,d)")
        factors = Z_seq.reshape(*Z_seq.shape[:-1], self.K, self.d_f)
        scores = factors.var(dim=-3, correction=1).sum(dim=-1)
        if scores.ndim == 2:
            scores = scores.mean(dim=0)
        return int(scores.argmax().item())

    def compute_loss(self, z_pred, z_target, *, z_context=None, orthogonality_weight=1.0):
        weight = _weight(orthogonality_weight, "orthogonality_weight")
        prediction = ijepa_prediction_loss(z_pred, z_target)
        if weight == 0:
            return prediction
        states = z_pred if z_context is None else z_context
        return prediction + weight * opf_orthogonality_loss(states, self.K)


class M3_IJEPA_SIGReg(M1_IJEPA1D):
    """I-JEPA plus the task's explicit isotropic mean/covariance penalty.

    This uses the requested formula rather than LeJEPA's full SIGReg algorithm.
    ``training_loss`` regularizes context embeddings; ``compute_loss`` can be
    supplied z_context, or by default regularizes z_pred. Weight zero disables it.
    Task 3 can additionally enable pointwise, non-affine sphere normalization.
    Its fixed radius is sqrt(d), i.e. unit coordinate RMS, compatible with the
    covariance-I objective. This never uses a whole orbit or future samples.
    """

    def __init__(self, *args, normalize_embeddings=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.normalize_embeddings = bool(normalize_embeddings)
        if self.normalize_embeddings:
            self.context_encoder = _SphereEncoder(self.context_encoder)
            self.target_encoder = copy.deepcopy(self.context_encoder).requires_grad_(False)
            self.target_encoder.eval()
            self.predictor = _SpherePredictor(self.predictor)

    def compute_loss(self, z_pred, z_target, *, z_context=None, sigreg_weight=1.0):
        weight = _weight(sigreg_weight, "sigreg_weight")
        prediction = ijepa_prediction_loss(z_pred, z_target)
        if weight == 0:
            return prediction
        states = z_pred if z_context is None else z_context
        return prediction + weight * sigreg_isotropic_loss(states)


class _SphereEncoder(nn.Module):
    """Pointwise LayerNorm plus fixed-RMS rescaling; no orbit-level fitting."""

    def __init__(self, encoder):
        super().__init__()
        self.base_encoder = encoder
        self.L, self.C, self.d, self.arch_type = encoder.L, encoder.C, encoder.d, encoder.arch_type

    def forward(self, x):
        raw = self.base_encoder(x)
        centered = raw - raw.mean(dim=-1, keepdim=True)
        normalized = torch.nn.functional.normalize(centered, p=2, dim=-1, eps=1e-12)
        return normalized * math.sqrt(self.d)


class _SpherePredictor(nn.Module):
    """Apply the same pointwise fixed-RMS constraint to generated M3 states."""

    def __init__(self, predictor):
        super().__init__()
        self.base_predictor = predictor
        self.d, self.H_max = predictor.d, predictor.H_max

    def forward(self, z_t, k=1):
        raw = self.base_predictor(z_t, k)
        centered = raw - raw.mean(dim=-1, keepdim=True)
        return torch.nn.functional.normalize(centered, p=2, dim=-1, eps=1e-12) * math.sqrt(self.d)
