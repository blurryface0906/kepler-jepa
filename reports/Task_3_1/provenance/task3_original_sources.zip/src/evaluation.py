"""Task 3 evaluation without orbital metadata in the frequency estimators.

T1/T2/T3 exclude the initial state and align to window starts delta..N_eval*delta.
T4 evaluates only the trained, direct horizons 1..H_train from the same origin.
All PCA transforms are independently fitted, unwhitened, and temporally centered
for each orbit and regime, as in Experiment 1. No physical origin is supplied.

Scale scores are in-sample linear diagnostics, not information-theoretic tests.
In particular, low linear R2 does not establish absence of nonlinear information,
and a constant state norm does not imply a constant trajectory cycle radius.
"""

from __future__ import annotations

from numbers import Integral

import numpy as np
import torch

from .spectral import (evaluate_kepler_regression, freq_s2_interpolated_fft,
                       freq_s3a_dmd_koopman, freq_s3b_phase_unwrap,
                       project_to_2d_mode)

METHODS = ("S2", "S3a_diff", "S3b_diff", "S3b_std")


def _integer(value, name, *, minimum=1):
    if isinstance(value, bool) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return int(value)


def _positive_scalar(value, name):
    if np.ndim(value) != 0 or not np.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")
    return float(value)


def _axes(values, count):
    if np.iscomplexobj(values):
        raise ValueError("semi_major_axes must be real")
    axes = np.asarray(values, dtype=np.float64)
    if axes.shape != (count,) or not np.all(np.isfinite(axes)) or np.any(axes <= 0):
        raise ValueError("semi_major_axes must have finite positive shape (N_orbits,)")
    return axes


def _latent(values, *, finite=True):
    if np.iscomplexobj(values):
        raise ValueError("latent trajectories must be real")
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 3 or array.shape[0] < 2 or array.shape[1] < 2 or array.shape[2] < 1:
        raise ValueError("latent trajectories must have shape (N>=2,T>=2,d>=1)")
    if finite and not np.all(np.isfinite(array)):
        raise ValueError("latent trajectories must be finite")
    return array


def _linear_fit(features, target, names, tolerance):
    """Fit centered, scaled OLS while dropping numerically constant predictors.

    A float32-normalized sphere has tiny apparent norm variation after promotion
    to float64. A predictor with log-coordinate std <= 1e-6 by default is treated
    as constant. The threshold, raw stds and dropped features are returned, so
    small-scale variation is disclosed rather than counted as reliable scale.
    """
    features = np.asarray(features, dtype=np.float64)
    if features.ndim == 1:
        features = features[:, None]
    feature_mean = features.mean(axis=0)
    centered = features - feature_mean
    feature_std = np.sqrt(np.mean(centered * centered, axis=0))
    active = feature_std > tolerance
    target_mean = float(target.mean())
    centered_target = target - target_mean
    coefficients = np.zeros(features.shape[1], dtype=np.float64)
    rank = 0
    if np.any(active):
        standardized = centered[:, active] / feature_std[active]
        scaled_coef, _, rank, _ = np.linalg.lstsq(standardized, centered_target, rcond=None)
        coefficients[active] = scaled_coef / feature_std[active]
    fitted_centered = centered @ coefficients
    residual = centered_target - fitted_centered
    sse, sst = float(residual @ residual), float(centered_target @ centered_target)
    defined = not np.all(target == target[0])
    ratio = sse / sst if defined and sst > 0 else float("nan")
    return {"r2": 1.0 - ratio, "one_minus_r2": ratio, "sse": sse, "sst": sst,
            "intercept": float(target_mean - feature_mean @ coefficients),
            "coefficients": {name: float(value) for name, value in zip(names, coefficients)},
            "feature_std": {name: float(value) for name, value in zip(names, feature_std)},
            "active_features": [name for name, enabled in zip(names, active) if enabled],
            "dropped_constant_features": [name for name, enabled in zip(names, active) if not enabled],
            "feature_std_tolerance": tolerance, "design_rank": int(rank),
            "status": "ok" if defined else "undefined_constant_response"}


def _rank(values):
    """Average ranks for ties without adding a scipy runtime dependency."""
    order = np.argsort(values, kind="stable")
    ranked = np.empty(len(values), dtype=np.float64)
    begin = 0
    while begin < len(values):
        end = begin + 1
        while end < len(values) and values[order[end]] == values[order[begin]]:
            end += 1
        ranked[order[begin:end]] = (begin + end - 1) / 2
        begin = end
    return ranked


def _spearman(x, y, tolerance):
    if np.std(x) <= tolerance or np.all(y == y[0]):
        return float("nan")
    xr, yr = _rank(x), _rank(y)
    xr, yr = xr - xr.mean(), yr - yr.mean()
    denominator = np.sqrt((xr @ xr) * (yr @ yr))
    return float((xr @ yr) / denominator) if denominator else float("nan")


def evaluate_scale_preservation(Z_all_orbits, semi_major_axes, mu=1.0, *,
                                numerical_feature_tol=1e-6):
    """Evaluate the specified scale/energy regressions and retain all predictors.

    s_i = log(sqrt(mean_t(||z_it - mean_t(z_i)||^2) + 1e-12)); r_i
    uses the uncentered norm. Energy is log(mu/(2*a)), so its target contains no
    independent information beyond log(a). A constant predictor against varying
    axes gives R2=0. Constant axes give undefined R2, never a spurious perfect fit.
    All input states must be finite; callers must retain failed-run diagnostics.
    """
    values = _latent(Z_all_orbits)
    axes = _axes(semi_major_axes, len(values))
    mu = _positive_scalar(mu, "mu")
    tolerance = _positive_scalar(numerical_feature_tol, "numerical_feature_tol")
    centered = values - values.mean(axis=1, keepdims=True)
    with np.errstate(over="ignore", invalid="ignore"):
        cycle_square = np.mean(np.sum(centered * centered, axis=2), axis=1)
        state_square = np.mean(np.sum(values * values, axis=2), axis=1)
        s, r = 0.5 * np.log(cycle_square + 1e-12), 0.5 * np.log(state_square + 1e-12)
    if not np.all(np.isfinite(s)) or not np.all(np.isfinite(r)):
        raise ValueError("latent norms overflowed; scale regressions are undefined")
    log_a = np.log(axes)
    log_energy = np.log(mu / 2) - log_a
    cycle_fit = _linear_fit(s, log_a, ["s"], tolerance)
    state_fit = _linear_fit(r, log_a, ["r"], tolerance)
    energy_fit = _linear_fit(np.column_stack((s, r)), log_energy, ["s", "r"], tolerance)
    rho = _spearman(s, log_a, tolerance)
    return {"scale_r2_cycle_radius": cycle_fit["r2"],
            "scale_r2_state_norm": state_fit["r2"], "energy_r2": energy_fit["r2"],
            "n_orbits": len(values), "n_samples": values.shape[1], "latent_dim": values.shape[2],
            "s": s.tolist(), "r": r.tolist(), "log_a": log_a.tolist(),
            "log_abs_energy": log_energy.tolist(),
            "cycle_radius_rms": np.sqrt(cycle_square + 1e-12).tolist(),
            "state_norm_rms": np.sqrt(state_square + 1e-12).tolist(),
            "fits": {"cycle_radius": cycle_fit, "state_norm": state_fit, "energy": energy_fit},
            "cycle_radius_spearman": rho,
            "cycle_radius_direction": ("increasing" if rho > 0 else "decreasing" if rho < 0
                                       else "constant_or_undefined" if not np.isfinite(rho)
                                       else "nonmonotonic"),
            "energy_target_is_affine_log_a": True,
            "interpretation": "In-sample linear probes; low R2 does not establish loss of all scale information."}


def regime_metadata(*, N_eval=256, L=16, delta=4, H_train=64, dt=0.01, start=0):
    """Return exact window-start indices and time coordinates for each regime."""
    N_eval, L, delta, H_train, start = (
        _integer(value, name, minimum=minimum) for value, name, minimum in (
            (N_eval, "N_eval", 2), (L, "L", 1), (delta, "delta", 1),
            (H_train, "H_train", 2), (start, "start", 0)))
    dt = _positive_scalar(dt, "dt")
    indices = {name: (start + delta * np.arange(1, count + 1)).tolist()
               for name, count in (("T1", N_eval), ("T2", N_eval), ("T3", N_eval), ("T4", H_train))}
    return {"N_eval": N_eval, "L": L, "delta": delta, "H_train": H_train,
            "dt": dt, "macro_dt": delta * dt, "origin_window_start_index": start,
            "excludes_z0": True, "window_start_indices": indices,
            "sample_times": {name: (np.asarray(index, dtype=np.float64) * dt).tolist()
                             for name, index in indices.items()},
            "required_raw_samples": start + N_eval * delta + L,
            "pca": "per-orbit, per-regime, centered unwhitened leading two components"}


def evaluate_regimes(model, trajectories, *, N_eval=256, L=16, delta=4,
                     H_train=64, dt=0.01, start=0, device=None, dtype=None,
                     batch_size=1024):
    """Return T1..T4 NumPy arrays (N,T,d), sharing an initial encoded window.

    T1 encodes true future windows; T2 predicts each from the true immediately
    preceding window. T3 uses only the initial window then repeatedly token 1.
    T4 uses only that initial window, independently with tokens 1..H_train.
    Generated nonfinite states are retained for honest failed-orbit evaluation.
    The model's train/eval mode is restored. Model weights are never converted.
    """
    metadata = regime_metadata(N_eval=N_eval, L=L, delta=delta, H_train=H_train,
                               dt=dt, start=start)
    batch_size = _integer(batch_size, "batch_size")
    if np.iscomplexobj(trajectories):
        raise ValueError("trajectories must be real")
    states = np.asarray(trajectories)
    encoder = model.context_encoder
    if (states.ndim != 3 or states.shape[0] < 1 or states.shape[-1] != encoder.C
            or states.shape[1] < metadata["required_raw_samples"]
            or not np.all(np.isfinite(states))):
        raise ValueError("trajectories must be finite (N,T,C) with enough raw samples and matching channels")
    if encoder.L != L:
        raise ValueError("L must match the model encoder")
    if model.predictor.H_max < H_train:
        raise ValueError("T4 exceeds the model's available horizon tokens")
    first_parameter = next(model.parameters(), None)
    inferred_device = first_parameter.device if first_parameter is not None else torch.device("cpu")
    inferred_dtype = first_parameter.dtype if first_parameter is not None else torch.float32
    device = inferred_device if device is None else torch.device(device)
    dtype = inferred_dtype if dtype is None else dtype
    if dtype not in (torch.float32, torch.float64):
        raise ValueError("dtype must be float32 or float64")
    same_device = (device.type == inferred_device.type and
                   (device.index is None or device.index == inferred_device.index))
    if first_parameter is not None and (not same_device or dtype != inferred_dtype):
        raise ValueError("device/dtype must match model weights; evaluation must not convert trained weights")
    window_starts = start + delta * np.arange(N_eval + 1)
    sample_indices = window_starts[:, None] + np.arange(L)[None, :]
    windows = torch.as_tensor(np.array(states[:, sample_indices, :], copy=True), device=device, dtype=dtype)
    original_mode = model.training
    try:
        model.eval()
        with torch.inference_mode():
            encoded = model.encode_sequence(windows, batch_size=batch_size)
            z0 = encoded[:, 0]
            predecessors = encoded[:, :-1].reshape(-1, encoded.shape[-1])
            teacher = torch.cat([model.predictor(chunk, 1) for chunk in predecessors.split(batch_size)])
            teacher = teacher.reshape(states.shape[0], N_eval, encoded.shape[-1])
            state, autoregressive = z0, []
            for _ in range(N_eval):
                state = model.predictor(state, 1)
                autoregressive.append(state)
            direct = [model.predictor(z0, k) for k in range(1, H_train + 1)]
            sequences = {"T1": encoded[:, 1:], "T2": teacher,
                         "T3": torch.stack(autoregressive, dim=1),
                         "T4": torch.stack(direct, dim=1)}
            return {key: value.detach().cpu().to(torch.float64).numpy().copy()
                    for key, value in sequences.items()}
    finally:
        model.train(original_mode)


def evaluate_frequencies(Z_all_orbits, semi_major_axes, dt=0.04):
    """Return all four methods, retaining every failed orbit in the regression.

    Each record includes omega_est, errors, invalid count, and Kepler metrics.
    One invalid/nonpositive frequency makes the full regression undefined: no
    selection of successful orbits is made. A constant-frequency fit retains
    the existing spectral module's undefined R2 semantics.
    """
    values = _latent(Z_all_orbits, finite=False)
    if values.shape[-1] < 2:
        raise ValueError("Frequency evaluation needs latent_dim >= 2")
    axes = _axes(semi_major_axes, len(values))
    dt = _positive_scalar(dt, "dt")
    estimates = {method: [] for method in METHODS}
    errors = {method: [] for method in METHODS}
    for orbit in values:
        try:
            mode = project_to_2d_mode(orbit)
            projection_error = None
        except (ValueError, np.linalg.LinAlgError) as exc:
            mode, projection_error = None, str(exc)
        for method in METHODS:
            try:
                if projection_error:
                    raise ValueError(projection_error)
                if method == "S2":
                    frequency = freq_s2_interpolated_fft(mode, dt)
                elif method == "S3a_diff":
                    frequency = freq_s3a_dmd_koopman(mode, dt, use_differences=True)
                else:
                    frequency = freq_s3b_phase_unwrap(mode, dt, use_differences=method.endswith("diff"))
                if not np.isfinite(frequency) or frequency <= 0:
                    raise ValueError("Frequency estimate is nonfinite or nonpositive")
                error = None
            except (ValueError, np.linalg.LinAlgError, FloatingPointError) as exc:
                frequency, error = float("nan"), str(exc)
            estimates[method].append(float(frequency))
            errors[method].append(error)
    results = {}
    for method in METHODS:
        frequency = np.asarray(estimates[method])
        invalid = int(np.count_nonzero(~np.isfinite(frequency) | (frequency <= 0)))
        metrics = {name: float("nan") for name in ("slope", "intercept", "slope_abs_error", "r2",
                                                  "one_minus_r2", "log10_one_minus_r2")}
        regression_error = None
        if invalid == 0:
            try:
                metrics = evaluate_kepler_regression(axes, frequency)
            except ValueError as exc:
                regression_error = str(exc)
        else:
            regression_error = "At least one invalid orbit; regression is undefined without filtering."
        results[method] = {"method": method, "n_orbits": len(values), "n_samples": values.shape[1],
                           "dt": dt, "semi_major_axes": axes.tolist(), "omega_est": estimates[method],
                           "errors": errors[method], "invalid": invalid,
                           "invalid_orbit_indices": np.flatnonzero(~np.isfinite(frequency) | (frequency <= 0)).tolist(),
                           "regression_error": regression_error, **metrics}
    return results
