"""Task 3: full CUDA training (15 runs) and circular T1--T4 diagnostics.

Production defaults never fall back to CPU or shorten the requested protocol.
For engineering checks only, --smoke-test writes under Task_3/smoke and labels
every artifact accordingly. --preflight checks the GPU without training.
"""

from __future__ import annotations

import argparse
from contextlib import redirect_stdout
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np
import torch
from threadpoolctl import threadpool_limits

from src.dataset import build_dataset_circ
from src.evaluation import (METHODS, evaluate_frequencies, evaluate_regimes,
                            evaluate_scale_preservation, regime_metadata)
from src.models import M0_RandomJEPA, M1_IJEPA1D, M2_JEPA_OPF, M3_IJEPA_SIGReg
from src.simulator import DT, generate_kepler_analytical
from src.spectral import project_to_2d_mode
from src.train import TrainConfig, train_model
from .exp1_encoder_tautology import _safe_json, _Tee, _write_json
from .exp2_reporting import write_report

ROOT = Path(__file__).resolve().parents[1]
SEEDS = (42, 43, 44, 45, 46)
MODELS = {"M0": M0_RandomJEPA, "M1": M1_IJEPA1D, "M2": M2_JEPA_OPF, "M3": M3_IJEPA_SIGReg}


def gpu_preflight():
    available = torch.cuda.is_available()
    gpus = []
    if available:
        for index in range(torch.cuda.device_count()):
            info = torch.cuda.get_device_properties(index)
            gpus.append({"index": index, "name": info.name, "total_memory_bytes": info.total_memory,
                         "capability": list(torch.cuda.get_device_capability(index))})
    return {"cuda_available": available, "torch": str(torch.__version__),
            "cuda_runtime": torch.version.cuda, "python": platform.python_version(),
            "platform": platform.platform(), "gpus": gpus,
            "checked_at_utc": datetime.now(timezone.utc).isoformat()}


def _source_hashes():
    files = ("src/models.py", "src/losses.py", "src/train.py", "src/evaluation.py", "src/dataset.py",
             "src/simulator.py", "src/spectral.py", "experiments/exp2_circular_trained.py",
             "experiments/exp2_reporting.py", "requirements-gpu.txt")
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files}


def _model(name, seed, device):
    torch.manual_seed(seed)
    kwargs = {"L": 16, "C": 4, "d": 64, "H_max": 64, "arch_type": "mlp", "dtype": torch.float32}
    if name == "M3":
        kwargs["normalize_embeddings"] = True
    return MODELS[name](**kwargs).to(device)


def _test_batches(seed, raw_count):
    batches = {}
    for split, source in (("test_id_sub", "test_id"), ("test_ood", "test_ood")):
        meta = build_dataset_circ(source, seed)["meta"]
        selected = (meta["a"] >= .5) & (meta["a"] <= 2) if split == "test_id_sub" else np.ones(len(meta["a"]), bool)
        a, phase = meta["a"][selected], meta["M0"][selected]
        states = generate_kepler_analytical(a[:,None], np.zeros((len(a),1)),
                                            np.arange(raw_count, dtype=np.float64)[None] * DT,
                                            M0=phase[:,None])
        batches[split] = {"trajectories": states, "a": a}
    return batches


def _criterion(checks, label, records, predicate, *, expected=5):
    valid = len(records) == expected
    passed = valid and all(predicate(row) for row in records)
    checks.append({"criterion": label, "passed": bool(passed),
                   "n_seed_records": len(records), "expected_seed_records": expected,
                   "details": [{"seed": row["seed"], **{key: row.get(key) for key in
                       ("slope_abs_error", "r2", "invalid", "scale_r2_cycle_radius")}}
                               for row in records]})


def acceptance_checks(report):
    """Apply ID acceptance to one predeclared method; OOD is reported separately."""
    checks = []
    production = not report["protocol"]["smoke_test"]
    complete = len(report["training_runs"]) == 15 and all(
        row.get("completed_steps") == 2000 and row.get("device", "").startswith("cuda")
        and row.get("status") == "completed" for row in report["training_runs"])
    checks.append({"criterion": "All 15 CUDA training runs completed 2000 steps, batch 256",
                   "passed": bool(production and complete)})
    method = report["protocol"]["primary_method"]
    frequencies = [r for r in report["frequency_runs"] if r["split"] == "test_id_sub" and r["method"] == method]
    for model in ("M0", "M1", "M2"):
        selected = [r for r in frequencies if r["model"] == model and r["regime"] == "T1"]
        _criterion(checks, f"ID T1 {model}: slope error<.005 and R2>.9999 ({method})", selected,
                   lambda r: r["invalid"] == 0 and r["slope_abs_error"] < .005 and r["r2"] > .9999)
    for regime in ("T3", "T4"):
        selected = [r for r in frequencies if r["model"] == "M0" and r["regime"] == regime]
        _criterion(checks, f"ID {regime} M0 fails law recovery ({method})", selected,
                   lambda r: r["invalid"] > 0 or not np.isfinite(r["r2"])
                   or r["slope_abs_error"] > .4 or r["r2"] < .80)
        for model in ("M1", "M2"):
            selected = [r for r in frequencies if r["model"] == model and r["regime"] == regime]
            _criterion(checks, f"ID {regime} {model}: slope error<.08 and R2>.98 ({method})", selected,
                       lambda r: r["invalid"] == 0 and r["slope_abs_error"] < .08 and r["r2"] > .98)
    for regime in ("T1", "T3"):
        for model in ("M1", "M2", "M3"):
            selected = [r for r in report["scale_runs"] if r["split"] == "test_id_sub"
                        and r["model"] == model and r["regime"] == regime]
            _criterion(checks, f"H4 ID {regime} {model}: cycle-radius R2 " + ("<.15" if model == "M3" else ">.90"),
                       selected, lambda r, model=model: r.get("status") == "completed"
                       and np.isfinite(r["scale_r2_cycle_radius"])
                       and (r["scale_r2_cycle_radius"] < .15 if model == "M3" else r["scale_r2_cycle_radius"] > .90))
    return checks


def _evaluate(model, name, seed, batches, report, config, n_eval):
    for split, batch in batches.items():
        sequences = evaluate_regimes(model, batch["trajectories"], N_eval=n_eval, L=16,
                                      delta=config.delta, H_train=config.horizon, dt=DT,
                                      device=config.device)
        a = batch["a"]
        for regime, latent in sequences.items():
            results = evaluate_frequencies(latent, a, dt=config.delta * DT)
            for method, result in results.items():
                report["frequency_runs"].append({"seed": seed, "model": name, "split": split,
                                                  "regime": regime, **result})
            if regime in ("T1", "T3"):
                try:
                    scale = {"status": "completed", **evaluate_scale_preservation(latent, a)}
                except ValueError as error:
                    scale = {"status": "invalid", "error": str(error),
                             "scale_r2_cycle_radius": float("nan"), "scale_r2_state_norm": float("nan"),
                             "energy_r2": float("nan")}
                report["scale_runs"].append({"seed": seed, "model": name, "split": split,
                                              "regime": regime, **scale})
            if seed == 42 and split == "test_id_sub" and regime == "T3" and name in ("M0", "M1", "M2"):
                index = int(np.argmin(np.abs(np.log(a))))
                try:
                    portrait = {"U": project_to_2d_mode(latent[index]).tolist(), "error": None}
                except (ValueError, np.linalg.LinAlgError) as error:
                    portrait = {"U": None, "error": str(error)}
                report["portraits"].append({"seed": seed, "model": name, "split": split,
                                             "orbit_index": index, "a": float(a[index]), **portrait})
        print(f"seed={seed} model={name} split={split}: evaluated T1/T2/T3={n_eval}, T4={config.horizon}", flush=True)


def run(args):
    config = (TrainConfig(steps=3, batch_size=8, horizon=4, ar_steps=2,
                           device="cpu", log_every=1, checkpoint_every=1, smoke_test=True)
              if args.smoke_test else TrainConfig(device=args.device))
    preflight = gpu_preflight()
    if not args.smoke_test and not preflight["cuda_available"]:
        _write_json(args.output / "gpu_preflight.json", preflight)
        print("CUDA unavailable. Full training was not started; no CPU substitution.", flush=True)
        return 2
    seeds, n_eval = ((42,), 16) if args.smoke_test else (SEEDS, 256)
    metadata = regime_metadata(N_eval=n_eval, delta=config.delta, H_train=config.horizon)
    report = {"experiment": "exp2_circular_trained", "status": "running",
              "started_at_utc": datetime.now(timezone.utc).isoformat(),
              "protocol": {"smoke_test": args.smoke_test, "seeds": list(seeds),
                           "training": asdict(config), "arch_type": "mlp", "d": 64, "C": 4,
                           "primary_method": args.primary_method, "frequency_methods": list(METHODS),
                           "spectral_input": "full d=64 latent, per-orbit unwhitened PCA",
                           "M3_normalization": "pointwise centered sphere radius sqrt(d), encoder/target/predictor; no orbit whitening",
                           "M3_objective": "direct+AR+beta*SIGReg, beta=1; no M1/M2 variance barrier",
                           "sparsity_weight": 0.0, "regimes": metadata,
                           "acceptance_split": "test_id_sub", "ood": "diagnostic; no OOD threshold specified"},
              "environment": {**preflight, **{package: importlib.metadata.version(package) for package in
                                               ("numpy", "scipy", "scikit-learn", "matplotlib", "tabulate", "threadpoolctl")}},
              "source_sha256": _source_hashes(), "training_runs": [], "frequency_runs": [],
              "scale_runs": [], "portraits": [], "checks": []}
    json_path = args.output / "exp2_circular_results.json"
    _write_json(json_path, report)
    print("Task 3: " + ("CPU ENGINEERING SMOKE ONLY" if args.smoke_test else "FULL CUDA EXPERIMENT"), flush=True)
    print("Protocol: " + json.dumps(report["protocol"]), flush=True)
    print("GPU: " + json.dumps(preflight), flush=True)
    started = time.perf_counter()
    for seed in seeds:
        batches = _test_batches(seed, metadata["required_raw_samples"])
        report.setdefault("test_grids", {split: batch["a"].tolist() for split, batch in batches.items()})
        training_data = build_dataset_circ("train", seed)["trajectories"]
        for name in MODELS:
            model = _model(name, seed, config.device)
            if name != "M0":
                checkpoint = args.output / "checkpoints" / f"{name}_seed{seed}.pt"
                resume_path = checkpoint if args.resume and checkpoint.exists() else None
                print(f"seed={seed} model={name}: training steps={config.steps}, batch={config.batch_size}, device={config.device}", flush=True)

                def log(record):
                    print(f"seed={seed} model={name} step={record['step']}/{config.steps} "
                          f"loss={record['total']:.7g} direct={record['direct']:.6g} "
                          f"ar={record['ar']:.6g} var={record['variance']:.6g} "
                          f"ortho={record['orthogonality']:.6g} iso={record['isotropic']:.6g} "
                          f"elapsed={record['elapsed_seconds']:.1f}s", flush=True)
                    report["progress"] = {"seed": seed, "model": name, **record}
                    _write_json(json_path, report)

                try:
                    training = train_model(model, training_data, config, seed,
                                           checkpoint_path=checkpoint, log_callback=log,
                                           resume_from=resume_path, provenance={"experiment": "exp2", "seed": seed})
                    report["training_runs"].append({"seed": seed, "model": name, "status": "completed", **training})
                except (FloatingPointError, RuntimeError, ValueError) as error:
                    report["training_runs"].append({"seed": seed, "model": name, "status": "failed",
                                                    "error": str(error), "completed_steps": None,
                                                    "device": config.device})
                    print(f"seed={seed} model={name}: TRAINING FAILED: {error}", flush=True)
                    _write_json(json_path, report)
                    del model
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    continue
            _evaluate(model, name, seed, batches, report, config, n_eval)
            _write_json(json_path, report)
            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
    if report["source_sha256"] != _source_hashes():
        raise RuntimeError("Source changed during the experiment; refusing mixed-source results")
    report["checks"] = acceptance_checks(report)
    report["acceptance_passed"] = all(row["passed"] for row in report["checks"])
    report["elapsed_seconds"] = time.perf_counter() - started
    report["status"] = "smoke_completed" if args.smoke_test else "completed"
    report["execution_completed"] = len(report["training_runs"]) == len(seeds) * 3 and all(
        row["status"] == "completed" and row["completed_steps"] == config.steps for row in report["training_runs"])
    _write_json(json_path, report)
    write_report(report, args.output)
    for check in report["checks"]:
        print(("PASS" if check["passed"] else "FAIL") + ": " + check["criterion"], flush=True)
    print("Execution completed: " + str(report["execution_completed"]), flush=True)
    if args.smoke_test:
        print("SMOKE ONLY: no scientific acceptance or full GPU training claimed.", flush=True)
        return 0 if report["execution_completed"] else 1
    print("Overall scientific acceptance: " + ("PASS (exit 0)" if report["acceptance_passed"] else "NOT MET (exit 1)"), flush=True)
    return 0 if report["acceptance_passed"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "reports/Task_3")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--primary-method", choices=METHODS, default="S3b_diff")
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--smoke-test", action="store_true")
    args = parser.parse_args()
    if args.threads < 1:
        parser.error("threads must be positive")
    if args.smoke_test:
        args.output = args.output / "smoke"
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(args.threads)
    if args.preflight:
        preflight = gpu_preflight()
        _write_json(args.output / "gpu_preflight.json", preflight)
        print(json.dumps(preflight, indent=2))
        return 0 if preflight["cuda_available"] else 2
    log_name = "exp2_circular_stdout.txt"
    with (args.output / log_name).open("w", encoding="utf-8") as stream:
        with redirect_stdout(_Tee(sys.stdout, stream)), threadpool_limits(limits=args.threads):
            return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
