"""Task 3 reports: retain undefined outcomes and distinguish execution/criteria.

The publication figure is created only when its five-seed input records exist.
An unavailable GPU or incomplete run yields a pending Markdown report, never a
placeholder presented as a final experimental figure.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
from tabulate import tabulate

MODELS = ("M0", "M1", "M2", "M3")
REGIMES = ("T1", "T2", "T3", "T4")
METHODS = ("S2", "S3a_diff", "S3b_diff", "S3b_std")
SPLITS = ("test_id_sub", "test_ood")
COLORS = {"M0": "#667085", "M1": "#2468A2", "M2": "#D27A28", "M3": "#8B4E9F"}


def _seeds(report):
    protocol = report.get("protocol", {})
    return tuple(protocol.get("seeds", [42, 43, 44, 45, 46])) if isinstance(protocol, dict) else (42, 43, 44, 45, 46)


def _number(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _finite_values(records, key):
    return np.asarray([_number(record.get(key)) for record in records], dtype=np.float64)


def _moment(records, key):
    """An undefined seed makes the aggregate undefined; no nanmean selection."""
    values = _finite_values(records, key)
    invalid = int(np.count_nonzero(~np.isfinite(values)))
    if not len(values):
        return "pending"
    if invalid:
        return f"undefined ({invalid}/{len(values)} seeds)"
    std = float(values.std(ddof=1)) if len(values) > 1 else 0.0
    return f"{values.mean():.6g} ± {std:.3g}"


def _group(records, **selection):
    return [record for record in records if all(record.get(key) == value for key, value in selection.items())]


def _plain_json(value):
    if isinstance(value, dict):
        return {str(key): _plain_json(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain_json(item) for item in value]
    if isinstance(value, np.ndarray):
        return _plain_json(value.tolist())
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, (Path,)):
        return str(value)
    return value


def _figure_missing(report):
    expected = set(_seeds(report))
    missing = []
    if report.get("protocol", {}).get("smoke_test", False):
        missing.append("Engineering smoke test only; the publication figure requires the full five-seed CUDA experiment.")
    frequencies = report.get("frequency_runs", [])
    for model in ("M0", "M1", "M2"):
        for regime in REGIMES:
            group = _group(frequencies, model=model, split="test_id_sub", regime=regime, method="S3b_diff")
            present = {record.get("seed") for record in group}
            if present != expected or len(group) != len(expected):
                missing.append(f"ID S3b_diff {model}/{regime}: {len(group)}/{len(expected)} seed records")
    scales = report.get("scale_runs", [])
    for model in ("M1", "M2", "M3"):
        group = _group(scales, model=model, split="test_id_sub", regime="T1")
        if {record.get("seed") for record in group} != expected or len(group) != len(expected):
            missing.append(f"ID T1 scale {model}: {len(group)}/{len(expected)} seed records")
    portraits = report.get("portraits", [])
    for model in ("M0", "M1", "M2"):
        if not _group(portraits, model=model, split="test_id_sub", seed=42):
            missing.append(f"ID T3 portrait {model}, seed 42")
    return missing


def _frequency_table(report, split):
    records = report.get("frequency_runs", [])
    rows = []
    for model in MODELS:
        for regime in REGIMES:
            for method in METHODS:
                group = _group(records, model=model, split=split, regime=regime, method=method)
                invalid = sum(int(record.get("invalid", 0) or 0) for record in group)
                rows.append([model, regime, method, f"{len(group)}/{len(_seeds(report))}",
                             _moment(group, "slope"), _moment(group, "slope_abs_error"),
                             _moment(group, "r2"), _moment(group, "one_minus_r2"), invalid])
    return tabulate(rows, headers=["model", "regime", "method", "seeds", "slope mean ± SD",
                                   "|slope+1.5|", "R²", "SSE/SST", "invalid orbits"], tablefmt="github")


def _scale_table(report):
    records = report.get("scale_runs", [])
    rows = []
    for split in SPLITS:
        for model in ("M1", "M2", "M3"):
            for regime in ("T1", "T3"):
                group = _group(records, split=split, model=model, regime=regime)
                failed = sum(1 for record in group if record.get("error") or record.get("status") == "failed")
                rows.append([split, model, regime, f"{len(group)}/{len(_seeds(report))}",
                             _moment(group, "scale_r2_cycle_radius"), _moment(group, "scale_r2_state_norm"),
                             _moment(group, "energy_r2"), _moment(group, "cycle_radius_spearman"), failed])
    return tabulate(rows, headers=["split", "model", "regime", "seeds", "cycle-radius R²",
                                   "state-norm R²", "energy R²", "Spearman(s, log a)", "failed seeds"],
                    tablefmt="github")


def _plot_frequency_panel(axis, report):
    secondary = axis.twinx()
    x = np.arange(4)
    frequencies = report.get("frequency_runs", [])
    finite_errors, invalid_labels, zero_labels = [], [], []
    plot_data = {}
    for model in ("M0", "M1", "M2"):
        errors, error_stds, logs, log_stds = [], [], [], []
        for regime in REGIMES:
            records = _group(frequencies, model=model, split="test_id_sub", regime=regime, method="S3b_diff")
            error = _finite_values(records, "slope_abs_error")
            ratio = _finite_values(records, "one_minus_r2")
            if len(error) and np.all(np.isfinite(error)) and np.all(error >= 0):
                errors.append(float(error.mean()))
                error_stds.append(float(error.std(ddof=1)) if len(error) > 1 else 0.0)
                finite_errors.extend(error[error > 0].tolist())
                if not np.all(error > 0):
                    zero_labels.append(f"{model}/{regime}: exact-zero slope error")
            else:
                errors.append(float("nan"))
                error_stds.append(float("nan"))
                invalid_labels.append(f"{model}/{regime}: undefined slope")
            if len(ratio) and np.all(np.isfinite(ratio)) and np.all(ratio > 0):
                log_values = np.log10(ratio)
                logs.append(float(log_values.mean()))
                log_stds.append(float(log_values.std(ddof=1)) if len(ratio) > 1 else 0.0)
            else:
                logs.append(float("nan"))
                log_stds.append(float("nan"))
                if len(ratio) and np.all(np.isfinite(ratio)) and np.all(ratio >= 0) and np.any(ratio == 0):
                    zero_labels.append(f"{model}/{regime}: zero SSE/SST (log = −∞)")
                else:
                    invalid_labels.append(f"{model}/{regime}: undefined residual")
        plot_data[model] = (np.asarray(errors), np.asarray(error_stds), np.asarray(logs), np.asarray(log_stds))
    zero_location = min(finite_errors) * 0.1 if finite_errors else 1e-16
    for offset, model in enumerate(("M0", "M1", "M2")):
        errors, error_stds, logs, log_stds = plot_data[model]
        position = x + (offset - 1) * 0.045
        display_errors = np.where(errors == 0, zero_location, errors)
        axis.plot(position, display_errors, "-o", color=COLORS[model], linewidth=1.5, markersize=4)
        positive_band = np.isfinite(errors) & (errors - error_stds > 0)
        if np.any(positive_band):
            axis.fill_between(position[positive_band], errors[positive_band] - error_stds[positive_band],
                              errors[positive_band] + error_stds[positive_band], color=COLORS[model], alpha=0.09)
        secondary.plot(position, logs, "--s", color=COLORS[model], linewidth=1.25, markersize=3.5, alpha=0.85)
        finite = np.isfinite(logs) & np.isfinite(log_stds)
        if np.any(finite):
            secondary.fill_between(position[finite], logs[finite] - log_stds[finite],
                                   logs[finite] + log_stds[finite], color=COLORS[model], alpha=0.06)
    axis.set_yscale("log")
    axis.set_xticks(x, REGIMES)
    axis.set(xlabel="Evaluation regime", ylabel=r"$|\hat\beta_1+1.5|$ (solid)",
             title="(a) ID: phase differences, five seeds")
    secondary.set_ylabel(r"$\log_{10}(\mathrm{SSE}/\mathrm{SST})$ (dashed)")
    axis.grid(alpha=0.18)
    annotations = []
    if invalid_labels:
        annotations.append(f"Undefined aggregates: {len(invalid_labels)} metrics (see tables)")
    if zero_labels:
        annotations.append(f"Exact-zero metrics: {len(zero_labels)} (details in report/JSON)")
    if annotations:
        axis.text(0.02, -0.27, "\n".join(annotations), transform=axis.transAxes,
                  fontsize=7, va="top")
    handles = [Line2D([0], [0], color=COLORS[model], linewidth=2, label=model) for model in ("M0", "M1", "M2")]
    axis.legend(handles=handles, loc="best", fontsize=8, frameon=False)


def _plot_portraits(subgrid, figure, report):
    records = report.get("portraits", [])
    chosen = {}
    for model in ("M0", "M1", "M2"):
        group = _group(records, model=model, split="test_id_sub", seed=42)
        if group:
            chosen[model] = group[0]
    identities = {(record.get("orbit_index"), record.get("a")) for record in chosen.values()}
    matched = len(identities) == 1 and len(chosen) == 3
    for index, model in enumerate(("M0", "M1", "M2")):
        axis = figure.add_subplot(subgrid[0, index])
        record = chosen.get(model, {})
        try:
            mode = np.asarray(record.get("U", []), dtype=np.float64)
            valid = mode.ndim == 2 and mode.shape[0] >= 2 and mode.shape[1] == 2 and np.all(np.isfinite(mode))
        except (ValueError, TypeError):
            mode, valid = None, False
        if valid:
            axis.plot(mode[:, 0], mode[:, 1], color=COLORS[model], linewidth=1.1)
            axis.scatter(mode[0, 0], mode[0, 1], s=17, color=COLORS[model], marker="o", zorder=3)
            axis.scatter(mode[-1, 0], mode[-1, 1], s=20, color=COLORS[model], marker="x", zorder=3)
            axis.set_aspect("equal", adjustable="box")
        else:
            axis.text(0.5, 0.5, "Undefined / nonfinite\ntrajectory retained\nin detailed JSON", ha="center", va="center",
                      transform=axis.transAxes, fontsize=8)
        radius = _number(record.get("a"))
        label = f"a={radius:.3g}" if np.isfinite(radius) else "a unavailable"
        axis.set_title(model, fontsize=9, pad=18)
        if not matched:
            axis.text(0.04, 0.94, label, transform=axis.transAxes, ha="left", va="top", fontsize=7)
        axis.set_xlabel("PC1", fontsize=8)
        if index == 0:
            axis.set_ylabel("PC2 (own units)", fontsize=8)
        axis.tick_params(labelsize=6)
        axis.ticklabel_format(style="sci", axis="both", scilimits=(-2, 3), useMathText=True)
        axis.grid(alpha=0.15)
    figure.text(0.555, 0.87, "(b) Closed loop T3, seed 42", ha="center", fontsize=11)
    radius = _number(chosen.get("M0", {}).get("a"))
    match_text = f"Matched orbit a={radius:.3g}; " if matched and np.isfinite(radius) else "Orbit matching unavailable; "
    figure.text(0.555, 0.12, match_text + "own PCA axes and limits; ○ first, × last", ha="center", fontsize=7.5)


def _plot_scale_panel(axis, report):
    records = report.get("scale_runs", [])
    notes = []
    for model in ("M1", "M2", "M3"):
        group = _group(records, model=model, split="test_id_sub", regime="T1")
        axes, series, invalid = [], [], 0
        for record in group:
            try:
                x, s = np.asarray(record.get("log_a", []), dtype=np.float64), np.asarray(record.get("s", []), dtype=np.float64)
                valid = x.ndim == 1 and len(x) >= 2 and x.shape == s.shape and np.all(np.isfinite(x)) and np.all(np.isfinite(s))
            except (TypeError, ValueError):
                valid = False
            if valid:
                axes.append(x)
                series.append(s)
            else:
                invalid += 1
        if invalid or len(series) != len(_seeds(report)):
            notes.append(f"{model}: aggregate undefined ({invalid}/{len(group)} failed seeds)")
            continue
        if not all(x.shape == axes[0].shape and np.allclose(x, axes[0], atol=0, rtol=1e-12) for x in axes):
            notes.append(f"{model}: grids differ; raw seed curves shown")
            for x, s in zip(axes, series):
                order = np.argsort(x)
                axis.plot(x[order], s[order], color=COLORS[model], alpha=0.4, linewidth=0.8)
            continue
        values = np.stack(series)
        order = np.argsort(axes[0])
        x, mean = axes[0][order], values.mean(axis=0)[order]
        std = values.std(axis=0, ddof=1)[order] if len(values) > 1 else np.zeros_like(mean)
        axis.plot(x, mean, color=COLORS[model], label=model if model != "M3" else "M3 sphere", linewidth=1.6)
        axis.fill_between(x, mean - std, mean + std, color=COLORS[model], alpha=0.13)
    axis.set(xlabel=r"$\log a$", ylabel=r"$s=\log(\mathrm{RMS\ cycle\ radius})$",
             title="(c) H4 scale diagnostic, ID T1")
    axis.grid(alpha=0.18)
    handles, labels = axis.get_legend_handles_labels()
    if handles:
        axis.legend(frameon=False, fontsize=8)
    if notes:
        axis.text(0.03, 0.03, "\n".join(notes), transform=axis.transAxes, fontsize=6.5, va="bottom")


def _plot(report, target):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 11,
                         "axes.labelsize": 10, "savefig.dpi": 300, "axes.spines.top": False})
    figure = plt.figure(figsize=(18, 6.2))
    grid = figure.add_gridspec(1, 3, width_ratios=[1.1, 1.35, 1.0], left=0.055, right=0.985,
                              bottom=0.22, top=0.8, wspace=0.45)
    _plot_frequency_panel(figure.add_subplot(grid[0, 0]), report)
    _plot_portraits(grid[0, 1].subgridspec(1, 3, wspace=0.75), figure, report)
    _plot_scale_panel(figure.add_subplot(grid[0, 2]), report)
    figure.suptitle("Experiment 2: trained circular-orbit world models", fontsize=14, y=0.97)
    figure.text(0.5, 0.92, "Shown estimator S3b_diff; T1/T2/T3: 256 points; T4: 64 trained horizons; Δt = 0.04",
                ha="center", fontsize=9)
    figure.text(0.5, 0.055, "Bands: ±1 seed SD. Undefined seeds remain undefined in aggregates; all methods and ID/OOD outcomes are reported in JSON.",
                ha="center", fontsize=8)
    target.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(target, dpi=300, facecolor="white", metadata={"Software": "kepler-jepa Exp2"})
    plt.close(figure)


def _markdown(report, missing, figure_written):
    checks = report.get("checks", [])
    training = report.get("training_runs", [])
    failed = [check for check in checks if check.get("passed") is False]
    pending = [check for check in checks if check.get("passed") is None]
    execution = report.get("status", "unknown")
    smoke = report.get("protocol", {}).get("smoke_test", False)
    acceptance_text = "not evaluated (engineering smoke only)" if smoke else f"{len(failed)} failed, {len(pending)} pending"
    sections = ["# Experiment 2: GPU training and circular-orbit diagnostics", "",
                f"Execution status: **{execution}**. Completed training records: **{len(training)}**. "
                f"Scientific criteria: **{acceptance_text}**.", "",
                "Execution completion and scientific acceptance are separate outcomes. A completed run can fail "
                "a prespecified hypothesis; numerical results are retained without tuning them to pass.", ""]
    if smoke:
        sections.extend(["**CPU ENGINEERING SMOKE ONLY. These shortened runs do not test the scientific hypotheses "
                         "or satisfy the requested GPU experiment.**", ""])
    if missing:
        sections.extend(["## Pending publication figure", "",
                         "GPU experiments or required evaluation records are incomplete. No final publication figure "
                         "was generated from missing results.", "",
                         *[f"- {item}" for item in missing], ""])
    elif figure_written:
        sections.extend(["![Experiment 2 circular regimes](figures/exp2_circular_regimes.png)", ""])
    sections.extend(["## Protocol and numerical settings", "", "```json",
                     json.dumps(_plain_json(report.get("protocol", {})), indent=2, ensure_ascii=False), "```", "",
                     "T1 encodes true future windows. T2 predicts one step from each true predecessor. T3 repeatedly "
                     "uses horizon token 1 from one initial window. T4 predicts only trained horizons 1–64 from that "
                     "same initial window. All sequences exclude z0 and align to future window starts. "
                     "Each orbit/regime uses independent centered, unwhitened PCA for frequency estimation.", "",
                     "In the full production protocol, at δ=4 and simulator dt=0.01, T1/T2/T3 have 256 points separated by 0.04, spanning **10.20** "
                     "time units between the first and last samples; T4 has 64 points spanning **2.52**. "
                     "These windows do not cover multiple complete periods for every radius. In particular, long-period "
                     "OOD orbits are short arcs. Centering, finite-arc geometry and FFT resolution can affect estimates.", "",
                     "## Training execution", ""])
    if training:
        rows = [[run.get("seed", "?"), run.get("model", "?"), run.get("status", "recorded"),
                 run.get("completed_steps", run.get("steps_completed", run.get("steps", "see JSON"))), run.get("device", "see protocol"),
                 run.get("elapsed_seconds", "see JSON")] for run in training]
        sections.extend([tabulate(rows, headers=["seed", "model", "status", "steps", "device", "seconds"], tablefmt="github"), ""])
    else:
        sections.extend(["Pending: no completed GPU training records are available.", ""])
    sections.extend(["## Frequency regressions", "",
                     "Entries are mean ± sample standard deviation over the recorded seeds. The seed count is explicit. "
                     "An undefined seed makes the aggregate undefined; no `nanmean`, invalid-orbit filtering, or "
                     "best-seed selection is used. SSE/SST is computed directly rather than by subtracting rounded R².", ""])
    for split in SPLITS:
        sections.extend([f"### {split}", "", _frequency_table(report, split), ""])
    sections.extend(["## H4: scale and energy probes", "", _scale_table(report), "",
                     "The specified probes regress log(a) on log cycle radius s or log state norm r. "
                     "A predictor with log-feature standard deviation ≤1e−6 is treated as numerically constant by "
                     "default; the threshold, feature variation and dropped columns are retained in each JSON fit. "
                     "A constant predictor against varying axes has R²=0, while constant responses have undefined R².", "",
                     "Spearman(s, log a) supplies the direction and rank diagnostic: high linear R² alone does not "
                     "establish increasing monotonicity. The energy target log|E|=log(μ/2)−log(a) is affine in log(a), "
                     "so energy R² is a related scale probe rather than independent evidence of learned conservation.", "",
                     "Unit state norm does not imply a constant centered cycle radius on a finite arc. "
                     "Low R² of these linear norm probes also does not establish absence of nonlinear scale information "
                     "elsewhere in the representation. The M3 normalization result is therefore measured, not assumed.", "",
                     "## Prespecified scientific acceptance", ""])
    if checks:
        rows = [[check.get("criterion", "?"), "NOT EVALUATED (smoke)" if smoke else "PASS" if check.get("passed") is True else "FAIL" if check.get("passed") is False else "PENDING",
                 json.dumps(_plain_json(check.get("details", {})), ensure_ascii=False)] for check in checks]
        sections.extend([tabulate(rows, headers=["criterion", "status", "details"], tablefmt="github"), ""])
    else:
        sections.extend(["Pending: scientific criteria have not yet been evaluated.", ""])
    scale_failures = [record for record in report.get("scale_runs", []) if record.get("error")]
    if scale_failures:
        sections.extend(["### Failed scale diagnostics", "", tabulate(
            [[record.get("seed"), record.get("model"), record.get("split"), record.get("regime"), record.get("error")]
             for record in scale_failures], headers=["seed", "model", "split", "regime", "error"], tablefmt="github"), ""])
    sections.extend(["## Environment", "", "```json",
                     json.dumps(_plain_json(report.get("environment", {})), indent=2, ensure_ascii=False), "```", "",
                     "## Artifacts", "", "- [Full stdout](exp2_circular_stdout.txt)",
                     "- [All per-orbit and per-seed results](exp2_circular_results.json)",
                     "- [300 dpi publication figure](figures/exp2_circular_regimes.png)" if figure_written else "- Publication figure pending complete GPU evaluation records.", ""])
    return "\n".join(sections)


def write_report(report, output_dir):
    """Write Markdown and, for complete actual records, the 300 dpi figure.

    Return paths as {markdown: Path, figure: Path | None}. This helper never
    writes the orchestration JSON or stdout and never invents missing outcomes.
    """
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    missing = _figure_missing(report)
    figure = None
    if not missing:
        figure = output / "figures" / "exp2_circular_regimes.png"
        _plot(report, figure)
    markdown = output / "exp2_circular_report.md"
    markdown.write_text(_markdown(report, missing, figure is not None), encoding="utf-8")
    return {"markdown": markdown, "figure": figure}
