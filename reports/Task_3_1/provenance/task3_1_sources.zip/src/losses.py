"""Losses specified for the Task 2 controlled JEPA baselines.

Both covariance losses use the unbiased sample covariance, with divisor N - 1,
and therefore require at least two samples. The isotropic loss is the explicit
mean/covariance surrogate in the task; it is not LeJEPA's characteristic-function
SIGReg implementation and does not establish Gaussianity.
"""

from numbers import Integral, Real
import math

import torch
from torch.nn import functional as F


def _sample_matrix(z: torch.Tensor) -> None:
    if not isinstance(z, torch.Tensor) or not z.is_floating_point():
        raise ValueError("z must be a real floating-point tensor")
    if z.ndim != 2 or z.shape[0] < 2 or z.shape[1] < 1:
        raise ValueError("z must have shape (N >= 2, d >= 1)")


def ijepa_prediction_loss(z_pred: torch.Tensor, z_target: torch.Tensor) -> torch.Tensor:
    """Mean squared prediction error, with no gradient through the target."""
    if not isinstance(z_pred, torch.Tensor) or not isinstance(z_target, torch.Tensor):
        raise ValueError("predictions and targets must be tensors")
    if not z_pred.is_floating_point() or not z_target.is_floating_point():
        raise ValueError("predictions and targets must be real floating-point tensors")
    if z_pred.shape != z_target.shape or z_pred.numel() == 0:
        raise ValueError("predictions and targets must have equal, nonempty shapes")
    if z_pred.dtype != z_target.dtype or z_pred.device != z_target.device:
        raise ValueError("predictions and targets must have equal dtype and device")
    return F.mse_loss(z_pred, z_target.detach())


def opf_orthogonality_loss(z: torch.Tensor, K: int = 4,
                           eps: float = 1e-6) -> torch.Tensor:
    """Average squared Frobenius cross-correlation over ordered factor pairs.

    Each coordinate is centered and divided by its unbiased sample standard
    deviation, floored at ``eps``. A constant coordinate thus contributes zero.
    Correlations use the same N - 1 divisor. No within-factor penalty is added.
    """
    _sample_matrix(z)
    if isinstance(K, bool) or not isinstance(K, Integral) or K < 2 or z.shape[1] % K:
        raise ValueError("K must be an integer >= 2 that divides the latent dimension")
    if isinstance(eps, bool) or not isinstance(eps, Real) or not math.isfinite(eps) or eps <= 0:
        raise ValueError("eps must be finite and strictly positive")
    centered = z.reshape(z.shape[0], int(K), z.shape[1] // K)
    centered = centered - centered.mean(dim=0, keepdim=True)
    variance = centered.square().sum(dim=0, keepdim=True) / (z.shape[0] - 1)
    # Clamp before sqrt: sqrt(0) followed by a clamp can produce NaN gradients
    # on constant coordinates through an intermediate infinite derivative.
    standardized = centered / variance.clamp_min(float(eps)**2).sqrt()
    total = z.new_zeros(())
    for j in range(int(K)):
        for k in range(j + 1, int(K)):
            cross = standardized[:, j].T @ standardized[:, k] / (z.shape[0] - 1)
            total = total + cross.square().sum()
    return 2 * total / (K * (K - 1))


def sigreg_isotropic_loss(z: torch.Tensor) -> torch.Tensor:
    """Task-specified ``||mean||^2 + ||sample_covariance - I||_F^2``.

    This moment penalty alone does not exclude non-Gaussian representations.
    """
    _sample_matrix(z)
    mean = z.mean(dim=0)
    centered = z - mean
    covariance = centered.T @ centered / (z.shape[0] - 1)
    identity = torch.eye(z.shape[1], dtype=z.dtype, device=z.device)
    return mean.square().sum() + (covariance - identity).square().sum()
